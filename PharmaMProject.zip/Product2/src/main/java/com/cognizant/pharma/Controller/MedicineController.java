package com.cognizant.pharma.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.pharma.Entity.Medicine;
import com.cognizant.pharma.Service.MedicineService;

@Controller
@RequestMapping("/medicine")
public class MedicineController {
	@Autowired
	MedicineService medicineService;	
	@RequestMapping("/list")
	public String listMedicines(Model theModel) {
		List<Medicine> medicines =medicineService.getAllMedicines();
		theModel.addAttribute("medicines",medicines);
		System.out.println(medicines);
		return "medicineList";
	}
	@RequestMapping("/showFormForAdd")
	public String showFormForAdd(Model theModel) {
		Medicine medicine=new Medicine();
		theModel.addAttribute("medicine",medicine);
		return "medicineForm";
	}
	@RequestMapping("/saveMedicine")
	public String saveMedicine(@ModelAttribute("medicine")Medicine theMedicine) {
		medicineService.saveMedicine(theMedicine);
	return "redirect:/medicine/list";
	}

	@RequestMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("id") int theId,Model theModel)
	{
				Medicine theMedicine=medicineService.getMedicine(theId);
			theModel.addAttribute("medicine",theMedicine);
			return "medicineForm";
	}
	
	
	@RequestMapping("/delete")
	public String deleteMedicine(@RequestParam("id")int theId) {
		medicineService.deleteMedicine(theId);
		return "redirect:/medicine/list";
	}
	
	@PostMapping("/search")
	public String getAllMedicines(@RequestParam("medicineName") String medicinename,Model theModel) {
		List<Medicine> theMedicine=medicineService.getAllMedicines(medicinename);
		theMedicine.forEach(p ->System.out.println(p));
		theModel.addAttribute("medicines",theMedicine);
		return "medicineList";
	}

	@RequestMapping("/logout")
	public String Logout(Model theModel)
	{
		return "loginForm";
	}
}


