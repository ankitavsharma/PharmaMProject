package com.cognizant.pharma.Dao;

import java.util.List;

import com.cognizant.pharma.Entity.Medicine;

public interface MedicineDao {

	public List<Medicine> getAllMedicines();

	void saveMedicine(Medicine theMedicine);

	public Medicine getMedicine(int theId);

	public void deleteMedicine(int theId);
	
	public List<Medicine> getAllMedicines(String medicineName);

}
