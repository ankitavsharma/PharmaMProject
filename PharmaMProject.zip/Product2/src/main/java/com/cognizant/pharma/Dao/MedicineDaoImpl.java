package com.cognizant.pharma.Dao;


import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.pharma.Entity.Medicine;

@Repository
public class MedicineDaoImpl implements MedicineDao
{
	@Autowired
	private SessionFactory factory;
	

	@Transactional
	public List<Medicine> getAllMedicines() 
		{
		
		Session session = factory.getCurrentSession();
		Query<Medicine> query = session.createQuery("from Medicine", Medicine.class);
		List<Medicine> listOfMedicine = query.getResultList();
		System.out.println("***");
		listOfMedicine.forEach(c -> System.out.println(c));
		System.out.println("***");
		return listOfMedicine;

	}
	@Transactional
	public void saveMedicine(Medicine theMedicine) {
		Session session = factory.getCurrentSession();
		session.saveOrUpdate(theMedicine);
	}
	@Transactional
	public Medicine getMedicine(int theId) {
		Session session = factory.getCurrentSession();

		Medicine theMedicine = session.get(Medicine.class, theId);
		return theMedicine;
	}
	@Transactional
	public void deleteMedicine(int theId) {
		Session session = factory.getCurrentSession();
		Query theQuery = session.createQuery("delete from Medicine where id=:theId");

		theQuery.setParameter("theId", theId);
		theQuery.executeUpdate();
		System.out.println("delete method called");
	}
	@Override
	@Transactional
	public List<Medicine> getAllMedicines(String medicineName) {
		Session session =factory.getCurrentSession();
		Query query=null;
		if(medicineName!=null && medicineName.trim().length() >0) {
		query = session.createQuery("FROM Medicine WHERE medicineName like concat('%',:medicineName,'%')");
		query.setParameter("medicineName", medicineName);
		}
		else {
			query =session.createQuery("from Medicine");
		}
		List<Medicine> medicine = query.getResultList();
		System.out.println("************");
		medicine.forEach(p->System.out.println(p));
		System.out.println("************");
		return medicine;
		
	
	}

}