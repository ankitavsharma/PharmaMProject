package com.cognizant.pharma.Dao;

import com.cognizant.pharma.Entity.Login;

public interface UserDao {


	boolean validateUser(String uname, String pass);

	void saveUser(Login login);

}
