package com.cognizant.pharma.Entity;


	
	import java.sql.Date;

	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.persistence.Table;
	import javax.validation.constraints.NotNull;
	import javax.validation.constraints.Past;
	import javax.validation.constraints.Pattern;
	import javax.validation.constraints.Size;

	import org.hibernate.validator.constraints.NotBlank;
	import org.hibernate.validator.constraints.NotEmpty;
	import org.springframework.format.annotation.DateTimeFormat;
	import org.springframework.format.annotation.DateTimeFormat.ISO;


	@Entity
	@Table(name="medicine")
	public class Medicine {

		@Id
		@GeneratedValue(strategy=GenerationType.IDENTITY)
		@Column(name="id")
	private int Id;
		
		
	@Column(name="medicineName")
		@NotNull
	private String Name;
	
	@Column(name="typeOfMedicine")
	@NotNull
	private String Type;
		
		@Column(name="price")
		@NotNull
	private String Price;
		
	    
		@Column(name="DateOFManufacture")
		@NotNull
	private Date DateOfManufacture;
		
		@Column(name = "dateOfExpiry")
		@NotNull
		private Date ExpiryDate;

	public Medicine()
	{}

	public Medicine(int id, String type, String name, String price, Date dateOfManufacture,
			Date expiryDate) {
		super();
		Id = id;
		Type = type;
		Name = name;
		Price = price;
		DateOfManufacture = dateOfManufacture;
		ExpiryDate = expiryDate;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getPrice() {
		return Price;
	}

	public void setPrice(String price) {
		Price = price;
	}

	
	public Date getDateOfManufacture() {
		return DateOfManufacture;
	}

	public void setDateOfManufacture(Date dateOfManufacture) {
		DateOfManufacture = dateOfManufacture;
	}

	public Date getExpiryDate() {
		return ExpiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		ExpiryDate = expiryDate;
	}

	@Override
	public String toString() {
		return "Medicine [Id=" + Id + ", Type=" + Type + ", Name=" + Name + ", Price=" + Price + 
				 ", DateOfManufacture=" + DateOfManufacture + ", ExpiryDate=" + ExpiryDate + "]";
	}


	}