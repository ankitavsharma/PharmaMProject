package com.cognizant.pharma.Service;

import java.sql.DriverManager;
import java.sql.ResultSet;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class LoginService {
public boolean check(String uname, String pass) {
	
	try {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/pharma_project","root","root44");
		PreparedStatement pst= (PreparedStatement) con.prepareStatement("select * from login where uname=? and pass=?");
		pst.setString(1, uname);
		pst.setString(2, pass);
		ResultSet rs=pst.executeQuery();
		if(rs.next()) {
			System.out.println("connected");
			return true;
		}
	}
	catch(Exception e) {
		System.out.println(e);
	}
	
	
	return false;
}
}
