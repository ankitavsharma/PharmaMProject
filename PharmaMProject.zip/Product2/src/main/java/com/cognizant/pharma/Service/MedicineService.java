package com.cognizant.pharma.Service;

import java.util.List;

import com.cognizant.pharma.Entity.Medicine;


public interface MedicineService {

	List<Medicine> getAllMedicines();

	void saveMedicine(Medicine theMedicine);

	Medicine getMedicine(int theId);

	void deleteMedicine(int theId);
	
	public List<Medicine> getAllMedicines(String medicineName);

}
