package com.cognizant.pharma.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.pharma.Dao.MedicineDao;
import com.cognizant.pharma.Entity.Medicine;


@Service
public class MedicineServiceImpl implements MedicineService {
	@Autowired
	MedicineDao medicineDao;
	public List<Medicine> getAllMedicines() {
		// TODO Auto-generated method stub
		return medicineDao.getAllMedicines();
	}

	public void saveMedicine(Medicine theMedicine) {
		// TODO Auto-generated method stub
		 medicineDao.saveMedicine(theMedicine);
	}

	public Medicine getMedicine(int theId) {
		// TODO Auto-generated method stub
		return medicineDao.getMedicine(theId);
	}

	public void deleteMedicine(int theId) {
		// TODO Auto-generated method stub
		medicineDao.deleteMedicine(theId);
	}

	@Override
	public List<Medicine> getAllMedicines(String medicineName) {
		// TODO Auto-generated method stub
		return null;
	}

	

}

