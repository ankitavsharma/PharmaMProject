package com.cognizant.pharma.Service;

import com.cognizant.pharma.Entity.Login;

public interface UserService 
{

	boolean validateUser(String username, String password);

	void saveUser(Login login);	
}
