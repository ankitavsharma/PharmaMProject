package com.cognizant.pharma.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.pharma.Dao.UserDao;
import com.cognizant.pharma.Entity.Login;



@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDao userDao;
	
	@Override
	@Transactional
	public boolean validateUser(String username, String password) {
		return userDao.validateUser(username,password);
	}

	@Override
	@Transactional
	public void saveUser(Login login) {
		userDao.saveUser(login);
	}

}
