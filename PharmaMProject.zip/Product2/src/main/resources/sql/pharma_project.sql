drop database pharma_project;
create database pharma_project;
use pharma_project;



create table medicine(
id int(11) NOT NULL AUTO_INCREMENT,
medicineName varchar(25) DEFAULT NULL,
typeOfMedicine varchar(25) DEFAULT NULL,
price numeric(7,2) DEFAULT NULL,
dateOfManufacture date,
dateOfExpiry date,
PRIMARY KEY (id)

);
create table login(
uname varchar(20),
pass varchar(20));

insert into login values('admin','Pharma@10')